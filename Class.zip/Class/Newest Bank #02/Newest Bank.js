/*
        if(current_selection < 2){

            current_selection = 5;

        }else if(current_selection < 5){

            current_selection + 1;

        }else{

            current_selection = 1;

        }
*/

/*
        if(current_selection > 4){

            current_selection = 1;

        }else if(current_selection < 5){

            current_selection + 1;

        }else{

            current_selection = 1;

        }
*/

/*

document.getElementById("Location Display").style.position='absolute';



document.getElementById("Background 1").style.left= (128 - 128) + 'px';
document.getElementById("Background 1").style.top= (-900) + 'px';



document.getElementById("X Velocity Display").innerHTML = this.Velocity_x2;



P = 80

A = 65
D = 68

W = 87
S = 83

Numpad 4 = 100
Numpad 5 = 101



*/

document.getElementById("Selector").style.position='absolute';
document.getElementById("Current Menu").style.position='absolute';
document.getElementById("Current Choice").style.position='absolute';
document.getElementById("Customer 1 Name").style.position='absolute';
document.getElementById("Customer 1 Wallet").style.position='absolute';
document.getElementById("Customer 1 Income").style.position='absolute';
document.getElementById("Customer 1 Habit").style.position='absolute';
document.getElementById("Shop 1 Name").style.position='absolute';
document.getElementById("Provider 1 Name").style.position='absolute';
document.getElementById("Choice 1").style.position='absolute';
document.getElementById("Choice 2").style.position='absolute';
document.getElementById("Choice 3").style.position='absolute';
document.getElementById("Choice 4").style.position='absolute';
document.getElementById("Choice 5").style.position='absolute';

let current_menu, current_selection, customer_count, shop_count, screen_x, screen_y, holder, frame_pacer, delta_pacer, fps_target;

current_menu = 0;
current_selection = 1;
customer_count = 1;
shop_count = 1;

fps_target = 60;
delta_pacer = 1 / 60;
frame_pacer = delta_pacer * 1000;

screen_x = window.screen.width;
screen_y = window.screen.height;
holder = Date.now();

class Bank_Account{

    constructor(Agency, Card_Number, Money, Limit){
    
        this.Agency = Agency;
        this.Card_Number = Card_Number;
        this.Money = Money;
        this.Limit = Limit;
    
    }
    
    Deposit(){
    
        // console.log("Deposit is working.");
        console.log("Deposited $ 100.");
        this.Money = this.Money + 100;
        console.log("Money set to $",this.Money,".");
    
    }
    
}

class Customer{

    constructor(Name, Wallet, Income, Habit, M1_Stock, M2_Stock, M3_Stock, M4_Stock, M5_Stock){
    
        this.Name = Name;
        this.Wallet = Wallet;
        this.Income = Income;
        this.Habit = Habit;
        this.M1_Stock = M1_Stock;
        this.M2_Stock = M2_Stock;
        this.M3_Stock = M3_Stock;
        this.M4_Stock = M4_Stock;
        this.M5_Stock = M5_Stock;
    
    }
    
    Check_Price(Source_Price){

        if(this.Wallet >= Source_Price){

            if(current_selection < 2){

                this.M1_Stock += 1;
                Shop_1.M1_Stock -= 1;

            }else if(current_selection === 2){

                this.M2_Stock += 1;
                Shop_1.M2_Stock -= 1;

            }else if(current_selection === 3){

                this.M3_Stock += 1;
                Shop_1.M3_Stock -= 1;

            }else if(current_selection === 4){

                this.M4_Stock += 1;
                Shop_1.M4_Stock -= 1;

            }else if(current_selection === 5){

                this.M5_Stock += 1;
                Shop_1.M5_Stock -= 1;

            }

            this.Wallet -= Source_Price;
            Shop_1.Wallet += Source_Price;

        }else{



        }

    }



}

class Shop{

    constructor(Name, Wallet, Menu_Size, M1_Stock, M2_Stock, M3_Stock, M4_Stock, M5_Stock, M1_Price, M2_Price, M3_Price, M4_Price, M5_Price){
    
        this.Name = Name;
        this.Wallet = Wallet;
        this.Menu_Size = Menu_Size;
        this.M1_Stock = M1_Stock;
        this.M2_Stock = M2_Stock;
        this.M3_Stock = M3_Stock;
        this.M4_Stock = M4_Stock;
        this.M5_Stock = M5_Stock;

        this.M1_Price = M1_Price;
        this.M2_Price = M2_Price;
        this.M3_Price = M3_Price;
        this.M4_Price = M4_Price;
        this.M5_Price = M5_Price;
    
    }

    Check_Price(Source_Price){

        if(this.Wallet >= Source_Price){

            if(current_selection < 2){

                this.M1_Stock += 1;
                Provider_1.M1_Stock -= 1;

            }else if(current_selection === 2){

                this.M2_Stock += 1;
                Provider_1.M2_Stock -= 1;

            }else if(current_selection === 3){

                this.M3_Stock += 1;
                Provider_1.M3_Stock -= 1;

            }else if(current_selection === 4){

                this.M4_Stock += 1;
                Provider_1.M4_Stock -= 1;

            }else if(current_selection === 5){

                this.M5_Stock += 1;
                Provider_1.M5_Stock -= 1;

            }

            this.Wallet -= Source_Price;
            Provider_1.Wallet += Source_Price;

        }else{



        }

    }

}

class Provider{

    constructor(Name, Wallet, Menu_Size, M1_Stock, M2_Stock, M3_Stock, M4_Stock, M5_Stock, M1_Price, M2_Price, M3_Price, M4_Price, M5_Price){
    
        this.Name = Name;
        this.Wallet = Wallet;
        this.Menu_Size = Menu_Size;
        this.M1_Stock = M1_Stock;
        this.M2_Stock = M2_Stock;
        this.M3_Stock = M3_Stock;
        this.M4_Stock = M4_Stock;
        this.M5_Stock = M5_Stock;

        this.M1_Price = M1_Price;
        this.M2_Price = M2_Price;
        this.M3_Price = M3_Price;
        this.M4_Price = M4_Price;
        this.M5_Price = M5_Price;
    
    }
    

    
}

let Provider_1 = new Provider("P1", 1188, 5, 3, 5, 7, 11, 13, 16, 32, 64, 128, 256);
let Account_1 = new Bank_Account("Bank 1", 2048, 512, 600);
let Customer_1 = new Customer("C1", 1188, 1188, 0, 0, 0, 0, 0, 0);
let Shop_1 = new Shop("S1", 1188, 5, 3, 5, 7, 11, 13, 16, 32, 64, 128, 256);

Visual_Update();

/*

caller = setInterval(Main_Cycle, frame_pacer);



function Main_Cycle(){

    
    
    Visual_Update();

}

*/

/*

    <br> Choice 1: <span id="Choice 1"></span>
    <br> Choice 2: <span id="Choice 2"></span>
    <br> Choice 3: <span id="Choice 3"></span>
    <br> Choice 4: <span id="Choice 4"></span>
    <br> Choice 5: <span id="Choice 5"></span>

    <br> Current Menu: <span id="Current Menu"></span>
    <br> Current Choice: <span id="Current Choice"></span>

    <br> Name: <span id="Customer 1 Name"></span>
    <br> Money: <span id="Customer 1 Wallet"></span>
    <br> Income: <span id="Customer 1 Income"></span>
    <br> Habit: <span id="Customer 1 Habit"></span>

    <br> Shop Name: <span id="Shop 1 Name"></span>
    <br> Provider Name: <span id="Provider 1 Name"></span>

*/

/*


0 = Title Screen
1 = Start Menu
2 = General Menu
3 = Customer Menu
4 = Shopping Adjustments
5 = Provider Menu
6 = Shopping Menu
7 = Provision Calling

*/

function Visual_Update(){

    document.getElementById("Selector").style.top= (current_selection * 18) + 62 + 'px';

    document.getElementById("Current Menu").innerHTML = current_menu;
    document.getElementById("Current Choice").innerHTML = current_selection;

    document.getElementById("Customer 1 Name").innerHTML = Customer_1.Name;
    document.getElementById("Customer 1 Wallet").innerHTML = Customer_1.Wallet;
    document.getElementById("Customer 1 Income").innerHTML = Customer_1.Income;
    document.getElementById("Customer 1 Habit").innerHTML = Customer_1.Habit;

    document.getElementById("C1P1S").innerHTML = Customer_1.M1_Stock;
    document.getElementById("C1P2S").innerHTML = Customer_1.M2_Stock;
    document.getElementById("C1P3S").innerHTML = Customer_1.M3_Stock;
    document.getElementById("C1P4S").innerHTML = Customer_1.M4_Stock;
    document.getElementById("C1P5S").innerHTML = Customer_1.M5_Stock;

    document.getElementById("Shop 1 Name").innerHTML = Shop_1.Name;
    document.getElementById("Shop 1 Wallet").innerHTML = Shop_1.Wallet;

    document.getElementById("S1P1S").innerHTML = Shop_1.M1_Stock;
    document.getElementById("S1P2S").innerHTML = Shop_1.M2_Stock;
    document.getElementById("S1P3S").innerHTML = Shop_1.M3_Stock;
    document.getElementById("S1P4S").innerHTML = Shop_1.M4_Stock;
    document.getElementById("S1P5S").innerHTML = Shop_1.M5_Stock;

    document.getElementById("S1P1P").innerHTML = Shop_1.M1_Price;
    document.getElementById("S1P2P").innerHTML = Shop_1.M2_Price;
    document.getElementById("S1P3P").innerHTML = Shop_1.M3_Price;
    document.getElementById("S1P4P").innerHTML = Shop_1.M4_Price;
    document.getElementById("S1P5P").innerHTML = Shop_1.M5_Price;

    document.getElementById("Provider 1 Name").innerHTML = Provider_1.Name;
    document.getElementById("Provider 1 Wallet").innerHTML = Provider_1.Wallet;

    document.getElementById("P1P1S").innerHTML = Provider_1.M1_Stock;
    document.getElementById("P1P2S").innerHTML = Provider_1.M2_Stock;
    document.getElementById("P1P3S").innerHTML = Provider_1.M3_Stock;
    document.getElementById("P1P4S").innerHTML = Provider_1.M4_Stock;
    document.getElementById("P1P5S").innerHTML = Provider_1.M5_Stock;

    document.getElementById("P1P1P").innerHTML = Provider_1.M1_Price;
    document.getElementById("P1P2P").innerHTML = Provider_1.M2_Price;
    document.getElementById("P1P3P").innerHTML = Provider_1.M3_Price;
    document.getElementById("P1P4P").innerHTML = Provider_1.M4_Price;
    document.getElementById("P1P5P").innerHTML = Provider_1.M5_Price;

/*

    document.getElementById("Choice 1").innerHTML = this.Velocity_x2;
    document.getElementById("Choice 2").innerHTML = this.Velocity_x2;
    document.getElementById("Choice 3").innerHTML = this.Velocity_x2;
    document.getElementById("Choice 4").innerHTML = this.Velocity_x2;
    document.getElementById("Choice 5").innerHTML = this.Velocity_x2;

*/

    if(current_menu === 0){

    document.getElementById("Selector").style.left= (screen_x * -1) - 56 + 'px';

    document.getElementById("Choice 1").innerHTML = "";
    document.getElementById("Choice 2").innerHTML = "";
    document.getElementById("Choice 3").innerHTML = "";
    document.getElementById("Choice 4").innerHTML = "";
    document.getElementById("Choice 5").innerHTML = "";

    }else if(current_menu === 1){

        document.getElementById("Selector").style.left= (screen_x * 0.5) - (56 - 24) + 'px';

        document.getElementById("Choice 1").innerHTML = "Initiate";
        document.getElementById("Choice 2").innerHTML = "Continue";
        document.getElementById("Choice 3").innerHTML = "Load File";
        document.getElementById("Choice 4").innerHTML = "Settings";
        document.getElementById("Choice 5").innerHTML = "Options";

    }else if(current_menu === 2){

        document.getElementById("Choice 1").innerHTML = "Edit Customer";
        document.getElementById("Choice 2").innerHTML = "Edit Shop";
        document.getElementById("Choice 3").innerHTML = "Edit Provider";
        document.getElementById("Choice 4").innerHTML = "Go Shopping";
        document.getElementById("Choice 5").innerHTML = "Buy Provisions";

    }else if(current_menu === 3){

        document.getElementById("Choice 1").innerHTML = "Edit Name";
        document.getElementById("Choice 2").innerHTML = "Edit Wallet";
        document.getElementById("Choice 3").innerHTML = "Edit Income";
        document.getElementById("Choice 4").innerHTML = "Edit Habits";
        document.getElementById("Choice 5").innerHTML = "Reset Settings";

    }else if(current_menu === 4){

        document.getElementById("Choice 1").innerHTML = "Edit Product 1 Price";
        document.getElementById("Choice 2").innerHTML = "Edit Product 2 Price";
        document.getElementById("Choice 3").innerHTML = "Edit Product 3 Price";
        document.getElementById("Choice 4").innerHTML = "Edit Product 4 Price";
        document.getElementById("Choice 5").innerHTML = "Edit Product 5 Price";

    }else if(current_menu === 5){

        document.getElementById("Choice 1").innerHTML = "Provider Product 1 Stock";
        document.getElementById("Choice 2").innerHTML = "Provider Product 2 Stock";
        document.getElementById("Choice 3").innerHTML = "Provider Product 3 Stock";
        document.getElementById("Choice 4").innerHTML = "Provider Product 4 Stock";
        document.getElementById("Choice 5").innerHTML = "Provider Product 5 Stock";

    }else if(current_menu === 6){

        document.getElementById("Choice 1").innerHTML = "Capuccino $ 16";
        document.getElementById("Choice 2").innerHTML = "Milkshake $ 32";
        document.getElementById("Choice 3").innerHTML = "Root Beer $ 64";
        document.getElementById("Choice 4").innerHTML = "Moonshine $ 128";
        document.getElementById("Choice 5").innerHTML = "Fine Wine $ 256";

    }
    else if(current_menu === 7){

        document.getElementById("Choice 1").innerHTML = "Buy Capuccino $ 16";
        document.getElementById("Choice 2").innerHTML = "Buy Milkshake $ 32";
        document.getElementById("Choice 3").innerHTML = "Buy Root Beer $ 64";
        document.getElementById("Choice 4").innerHTML = "Buy Moonshine $ 128";
        document.getElementById("Choice 5").innerHTML = "Buy Fine Wine $ 256";

    }

}

document.addEventListener("keydown", function(event){

    if(event.keyCode === 65){



    }else if(event.keyCode == 68){


        
    }

});

document.addEventListener("keyup", function(event){

    if(event.keyCode === 65){



    }else if(event.keyCode === 68){



    }

});

// Code for directional input in the Z axis.

document.addEventListener("keydown", function(event){

    if(event.keyCode === 87){

        current_selection -= 1;
        if(current_selection < 1){current_selection = 5;}
        Visual_Update();

    }else if(event.keyCode == 83){

        current_selection += 1;
        if(current_selection > 5){current_selection = 1;}
        Visual_Update();

    }

});

document.addEventListener("keyup", function(event){

    if(event.keyCode === 87){



    }else if(event.keyCode === 83){



    }

});

document.addEventListener("keydown", function(event){

    if(event.keyCode === 101){



        if(current_menu <= 0){

            current_menu = 1;
        
        }else if(current_menu === 1){
        


            if(current_selection < 2){

                current_menu = 2;

            }else if(current_selection === 2){

                current_menu = 2;

            }else if(current_selection === 3){

                current_menu = 2;

            }else if(current_selection === 4){

                current_menu = 2;

            }else if(current_selection === 5){

                current_menu = 2;

            }
        


        }else if(current_menu === 2){
        


            if(current_selection < 2){

                current_menu = 3;

            }else if(current_selection === 2){

                current_menu = 4;

            }else if(current_selection === 3){

                current_menu = 5;

            }else if(current_selection === 4){

                current_menu = 6;

            }else if(current_selection === 5){

                current_menu = 7;

            }


        
        }else if(current_menu === 3){
        

        
            if(current_selection < 2){

                Customer_1.Name = prompt("Type in the customer's new name.");

            }else if(current_selection === 2){

                Customer_1.Wallet = prompt("Type in the customer's new money stock.");

            }else if(current_selection === 3){

                Customer_1.Income = prompt("Type in the customer's new income.");

            }else if(current_selection === 4){

                Customer_1.Habit = prompt("Type in the customer's new purchase tendency.");

            }else if(current_selection === 5){

                Customer_1.Name = "C1";
                Customer_1.Wallet = 1188;
                Customer_1.Income = 1188;
                Customer_1.Habit = 0;

            }



        }else if(current_menu === 4){
        


            if(current_selection < 2){

                Shop_1.M1_Price = prompt("Type in the first product's new price.");

            }else if(current_selection === 2){

                Shop_1.M2_Price = prompt("Type in the second product's new price.");

            }else if(current_selection === 3){

                Shop_1.M3_Price = prompt("Type in the third product's new price.");

            }else if(current_selection === 4){

                Shop_1.M4_Price = prompt("Type in the fourth product's new price.");

            }else if(current_selection === 5){

                Shop_1.M5_Price = prompt("Type in the fifth product's new price.");

            }

/*

            if(current_selection < 2){

                Shop_1.M1_Stock = prompt("Type in the first product's new stock.");

            }else if(current_selection === 2){

                Shop_1.M2_Stock = prompt("Type in the second product's new stock.");

            }else if(current_selection === 3){

                Shop_1.M3_Stock = prompt("Type in the third product's new stock.");

            }else if(current_selection === 4){

                Shop_1.M4_Stock = prompt("Type in the fourth product's new stock.");

            }else if(current_selection === 5){

                Shop_1.M5_Stock = prompt("Type in the fifth product's new stock.");

            }

*/
        
        }else if(current_menu === 5){
        


            if(current_selection < 2){



            }else if(current_selection === 2){



            }else if(current_selection === 3){



            }else if(current_selection === 4){



            }else if(current_selection === 5){



            }

        
        
        }else if(current_menu === 6){
        


            if(current_selection < 2){

                Customer_1.Check_Price(Shop_1.M1_Price);

            }else if(current_selection === 2){

                Customer_1.Check_Price(Shop_1.M2_Price);

            }else if(current_selection === 3){

                Customer_1.Check_Price(Shop_1.M3_Price);

            }else if(current_selection === 4){

                Customer_1.Check_Price(Shop_1.M4_Price);

            }else if(current_selection === 5){

                Customer_1.Check_Price(Shop_1.M5_Price);

            }


        
        }else if(current_menu === 7){
        


            if(current_selection < 2){

                Shop_1.Check_Price(Shop_1.M1_Price);

            }else if(current_selection === 2){

                Shop_1.Check_Price(Shop_1.M2_Price);

            }else if(current_selection === 3){

                Shop_1.Check_Price(Shop_1.M3_Price);

            }else if(current_selection === 4){

                Shop_1.Check_Price(Shop_1.M4_Price);

            }else if(current_selection === 5){

                Shop_1.Check_Price(Shop_1.M5_Price);

            }

        
        
        }

        Visual_Update();

    }

});

document.addEventListener("keyup", function(event){

    if(event.keyCode === 101){



    }

});

document.addEventListener("keydown", function(event){

    if(event.keyCode === 100){

        if(current_menu < 1){

            current_menu = 1;

        }else if(current_menu === 1){

            current_menu = 0;

        }else if(current_menu === 2){

            current_menu = 1;
            
        }else if(current_menu === 3){

            current_menu = 2;
            
        }else if(current_menu === 4){

            current_menu = 2;
            
        }else if(current_menu === 5){

            current_menu = 2;
            
        }else if(current_menu === 6){

            current_menu = 2;
            
        }else if(current_menu === 7){

            current_menu = 2;
            Customer_1.Wallet += Customer_1.Income;
            
        }

        Visual_Update();

    }

});

document.addEventListener("keydown", function(event){

    if(event.keyCode === 80){
    


    }

});

document.addEventListener("keyup", function(event){
    
    if(event.keyCode === 80){



    }

});

// Database Files Below

const express = require('express')

const app = express();

// Running this program, our computer becomes a server, and other computers can connect to ours by a "client" program.
// Check the folder "localhost://4000";

app.listen(4000, () => {
    console.log('aplicação rodando na porta 4000')
})

app.get('/', (request, response) => {
    response.send("Hello World")
})