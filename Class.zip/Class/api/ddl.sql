CREATE DATABASE toDo;

USE toDo;

CREATE TABLE TASKS (

    id int auto_increment not null primary key,
    tarefa varchar(85) not null,
    descrição text,
    responsavel varchar(85) not null
);