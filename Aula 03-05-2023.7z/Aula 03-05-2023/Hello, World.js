function hello_world(){
    console.log("Hello, world!");
}

console.log(hello_world);