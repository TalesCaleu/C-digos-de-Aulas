function Cálculo_de_Área(){
    let altura, largura, área;
    largura = Number(prompt("Digite a largura.")).
    altura = Number(prompt("Digite a alto.")).
    área = altura * largura;
    console.log("A área é", área, ".");
    return área;
}

console.log("O código retornou:", Cálculo_de_Área, ".");