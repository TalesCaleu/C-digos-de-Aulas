function Cumprimento(nome1, nome2, nome3){
    console.log("Olá,", nome1, ",", nome2, "e", nome3, ".");
}

let nome1o, nome2o, nome3o;

nome1o = prompt("Digite o primeiro nome.");
nome2o = prompt("Digite o segundo nome.");
nome3o = prompt("Digite o terceiro nome.");

console.log(Cumprimento(nome1o, nome2o, nome3o));