
function somar(numero1, numero2){
    return numero1 + numero2;
}

let retorno_soma = somar(1200, 300);

console.log(retorno_soma);