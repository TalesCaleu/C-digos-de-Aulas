



// Exemplo de declaração de função.
function Nome_da_função(parâmetro){}

// Exemplo de chamada de função.
console.log(Nome_da_função(20));







