let cycle, deposit_lenght, year_deposit, year_inflation, year_interest, general_rate, inflation_growth, interest_growth, real_growth, target_deposit, target_income, case_rounder, month_deposit, week_deposit;

case_rounder = 100;

cycle = 0;

deposit_lenght = Number(prompt("Digite o número de anos que você quer trabalhar até se aposentar."));
document.getElementById("Output_01").innerHTML = deposit_lenght;
document.getElementById("Output_08").innerHTML = deposit_lenght;
document.getElementById("Output_10").innerHTML = deposit_lenght;
document.getElementById("Output_11").innerHTML = deposit_lenght;

target_income = Number(prompt("Digite a quantidade de dinheiro que você quer receber por ano quando se aposentar."));
document.getElementById("Output_02").innerHTML = target_income;

year_interest = Number(prompt("Digite a taxa de juros compostos por ano, em porcentagem."));
document.getElementById("Output_03").innerHTML = year_interest;

year_inflation = Number(prompt("Digite a taxa de inflação por ano, em porcentagem."));
document.getElementById("Output_04").innerHTML = year_inflation;

year_interest = 1 + (year_interest / 100);
year_inflation = 1 + (year_inflation / 100);

// year_target_stock

general_rate = (year_interest / year_inflation) -1;
document.getElementById("Output_05").innerHTML = Math.floor(general_rate * case_rounder) / case_rounder;

console.log("A taxa de crescimento real é",Math.floor(general_rate*case_rounder*100)/case_rounder,"% por ano.");

target_deposit = Math.ceil((target_income * case_rounder) / general_rate) / case_rounder;
document.getElementById("Output_06").innerHTML = target_deposit;

console.log("Você precisa depositar R$", Math.ceil(target_deposit * case_rounder)/case_rounder,"pra que isso gere o equivalente a R$",Math.floor(target_income*case_rounder)/case_rounder,"por ano, após a inflação.");

cycle = deposit_lenght;
interest_growth = 1;

while (cycle > 0){

    interest_growth = interest_growth * year_interest;
    cycle -= 1;

}

document.getElementById("Output_07").innerHTML = Math.floor((interest_growth -1) * 100 * case_rounder) / case_rounder;

cycle = deposit_lenght;
inflation_growth = 1;

while (cycle > 0){

    inflation_growth = inflation_growth * year_inflation;
    cycle -= 1;

}

document.getElementById("Output_09").innerHTML = Math.floor((inflation_growth -1) * 100 * case_rounder) / case_rounder;

real_growth = interest_growth / inflation_growth;

document.getElementById("Output_12").innerHTML = Math.floor((real_growth -1) * 100 * case_rounder) / case_rounder;

year_deposit = Math.ceil((target_deposit * case_rounder) / real_growth) / case_rounder;

month_deposit = Math.ceil((year_deposit * case_rounder) / 12) / case_rounder;
week_deposit = Math.ceil((year_deposit * case_rounder) / 52.1775) / case_rounder;

document.getElementById("Output_13").innerHTML = year_deposit;
document.getElementById("Output_14").innerHTML = month_deposit;
document.getElementById("Output_15").innerHTML = week_deposit;

console.log("Você precisa depositar R$",year_deposit,"por ano durante",deposit_lenght,"anos.");
console.log("Ou R$",month_deposit,"por mês.");
console.log("Ou R$",week_deposit,"por semana.");

document.getElementById("Output_16").innerHTML = target_deposit;
document.getElementById("Output_17").innerHTML = Math.floor((year_deposit * interest_growth) * case_rounder) / 100;
document.getElementById("Output_18").innerHTML = target_income;

console.log("Com juros compostos, isso vai virar R$",target_deposit,".")
console.log("Gerando R$", Math.floor(target_income * case_rounder * inflation_growth) / 100, "por ano.");
console.log("O que é equivalente a R$",(year_deposit * real_growth) * general_rate,"depois da inflação.");
