let cycle, deposit_lenght, year_deposit, year_inflation, year_interest, general_rate, inflation_growth, interest_growth, real_growth, target_deposit, target_income, case_rounder, month_deposit, week_deposit;

case_rounder = 100;

cycle = 0;

deposit_lenght = Number(prompt("Type in the number of years you want to work for before you retire."));
document.getElementById("Output_01").innerHTML = deposit_lenght;
document.getElementById("Output_08").innerHTML = deposit_lenght;
document.getElementById("Output_10").innerHTML = deposit_lenght;
document.getElementById("Output_11").innerHTML = deposit_lenght;

target_income = Number(prompt("Type in the ammount of money you want to receive per year."));
document.getElementById("Output_02").innerHTML = target_income;

year_interest = Number(prompt("Type in the composite interest per year, in percentage."));
document.getElementById("Output_03").innerHTML = year_interest;

year_inflation = Number(prompt("Type in the inflation rate per year, in percentage."));
document.getElementById("Output_04").innerHTML = year_inflation;

year_interest = 1 + (year_interest / 100);
year_inflation = 1 + (year_inflation / 100);

// year_target_stock

general_rate = (year_interest / year_inflation) -1;
document.getElementById("Output_05").innerHTML = Math.floor(general_rate * case_rounder) / case_rounder;

console.log("The real growth rate is",Math.floor(general_rate*case_rounder*100)/case_rounder,"% per year.");

target_deposit = Math.ceil((target_income * case_rounder) / general_rate) / case_rounder;
document.getElementById("Output_06").innerHTML = target_deposit;

console.log("You need to deposit $", Math.ceil(target_deposit * case_rounder)/case_rounder,"in order to generate $",Math.floor(target_income*case_rounder)/case_rounder,".");

cycle = deposit_lenght;
interest_growth = 1;

while (cycle > 0){

    interest_growth = interest_growth * year_interest;
    cycle -= 1;

}

document.getElementById("Output_07").innerHTML = Math.floor((interest_growth -1) * 100 * case_rounder) / case_rounder;

cycle = deposit_lenght;
inflation_growth = 1;

while (cycle > 0){

    inflation_growth = inflation_growth * year_inflation;
    cycle -= 1;

}

document.getElementById("Output_09").innerHTML = Math.floor((inflation_growth -1) * 100 * case_rounder) / case_rounder;

real_growth = interest_growth / inflation_growth;

document.getElementById("Output_12").innerHTML = Math.floor((real_growth -1) * 100 * case_rounder) / case_rounder;

year_deposit = Math.ceil((target_deposit * case_rounder) / real_growth) / case_rounder;

month_deposit = Math.ceil((year_deposit * case_rounder) / 12) / case_rounder;
week_deposit = Math.ceil((year_deposit * case_rounder) / 52.1775) / case_rounder;

document.getElementById("Output_13").innerHTML = year_deposit;
document.getElementById("Output_14").innerHTML = month_deposit;
document.getElementById("Output_15").innerHTML = week_deposit;

console.log("You need to deposit $",year_deposit,"per year for",deposit_lenght,"years.");
console.log("Or $",month_deposit,"per month.");
console.log("Or $",week_deposit,"per week.");

document.getElementById("Output_16").innerHTML = target_deposit;
document.getElementById("Output_17").innerHTML = Math.floor((year_deposit * interest_growth) * case_rounder) / 100;
document.getElementById("Output_18").innerHTML = target_income;

console.log("With interest, that will become $",target_deposit,".")
console.log("Generating $", Math.floor(target_income * case_rounder * inflation_growth) / 100, "per year.");
console.log("Which is equivalent to $",(year_deposit * real_growth) * general_rate,"after inflation.");
