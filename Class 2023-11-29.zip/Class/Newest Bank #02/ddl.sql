CREATE DATABASE toDo;

USE toDo;

CREATE TABLE TASKS (

    id int auto_increment not null primary key,
    tarefa varchar(85) not null,
    descrição text,
    responsavel varchar(85) not null
);



CREATE TABLE SAVE (

    c1_name text default null;
    c1_wallet smallint default null;
    c1_income smallint default null;
    c1_habit smallint default null;

    c1_capuccino smallint default null;
    c1_milkshake smallint default null;
    c1_root_beer smallint default null;
    c1_moonshine smallint default null;
    c1_fine_wine smallint default null;

    s1_name text default null;
    s1_wallet smallint default null;

    s1_capuccino smallint default null;
    s1_milkshake smallint default null;
    s1_root_beer smallint default null;
    s1_moonshine smallint default null;
    s1_fine_wine smallint default null;

    p1_name text default null;
    p1_wallet smallint default null;

    p1_capuccino smallint default null;
    p1_milkshake smallint default null;
    p1_root_beer smallint default null;
    p1_moonshine smallint default null;
    p1_fine_wine smallint default null;

);

ALTER Save();