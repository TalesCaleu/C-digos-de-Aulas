/*
4 Answers
Sorted by:

Highest score (default)
4

You can use localStorage as a temporary storage between reads and writes.

Though, you cannot actually read and write to a user's filesystem at will using client side JavaScript. You can however request the user to select a file to read the same way you can request the user to save the data you push, as a file.

localStorage allow you to store the data as key-value pairs and it's easy to check if an item exists or not. Optionally simply use a literal object which basically can do the same but only exists in memory. localStorage can be saved between sessions and navigation between pages.

// set some data
localStorage.setItem("key", "value");

// get some data
var data = localStorage.getItem("key");

// check if key exists, set if not (though, you can simply override the key as well)
if (!localStorage.getItem("key")) localStorage.setItem("key", "value");
The method getItem will always return null if the key doesn't exist.

But note that localStorage can only store strings. For binary data and/or large sizes, look into Indexed DB instead.

To read a file you have to request the user to select one (or several):

HTML:

<label>Select a file: <input type=file id=selFile></label>
JavaScript

document.getElementById("selFile").onchange = function() {
  var fileReader = new FileReader();
  fileReader.onload = function() {
    var txt = this.result;
    // now we have the selected file as text.
  };
  fileReader.readAsText(this.files[0]);
};
To save a file you can use File objects this way:

var file = new File([txt], "myFilename.txt", {type: "application/octet-stream"});
var blobUrl = (URL || webkitURL).createObjectURL(file);
window.location = blobUrl;
The reason for using octet-stream is to "force" the browser to show a save as dialog instead of it trying to show the file in the tab, which would happen if we used text/plain as type.

So, how do we get the data between these stages. Assuming you're using key/value approach and text only you can use JSON objects.

var file = JSON.stringify(localStorage);
Then send to user as File blob shown above.

To read you will have to either manually parse the file format if the data exists in a particular format, or if the data is the same as you save out you can read in the file as shown above, then convert it from string to an object:

var data = JSON.parse(txt);        // continue in the function block above
Object.assign(localStorage, data); // merge data from object with localStorage
Note that you may have to delete items from the storage first. There is also the chance other data have been stored there so these are cases that needs to be considered, but this is the basis of one approach.

Example
// due to security reasons, localStorage can't be used in stacksnippet, 
// so we'll use an object instead
var test = {"myKey": "Hello there!"};   // localStorage.setItem("myKey", "Hello there!");

document.getElementById("selFile").onchange = function() {
  var fileReader = new FileReader();
  fileReader.onload = function() {
    var o = JSON.parse(this.result);
    //Object.assign(localStorage, o);   // use this with localStorage
    alert("done, myKey=" + o["myKey"]); // o[] -> localStorage.getItem("myKey")
  };
  fileReader.readAsText(this.files[0]);
};

document.querySelector("button").onclick = function() {
  var json = JSON.stringify(test);    // test -> localStorage
  var file = new File([json], "myFilename.txt", {type: "application/octet-stream"});
  var blobUrl = (URL || webkitURL).createObjectURL(file);
  window.location = blobUrl;
}
Save first: <button>Save file</button> (<code>"myKey" = "Hello there!"</code>)<br><br>

Then read the saved file back in:<br>
<label>Select a file: <input type=file id=selFile></label>
Expand snippet
*/

/*
const internal = require("stream");

let data_write;

data_write = 256;

// set some data
localStorage.setItem("Test storage", data_write);

// get some data
let data_retrive = localStorage.getItem("key");

// check if key exists, set if not (though, you can simply override the key as well)
if (!localStorage.getItem("key")) localStorage.setItem("key", "value");
*/


let Data_Storage_1[Info_01, Info_02, Info_03, Info_04, Info_05, Info_06];


Data_Storage_1[1] = "The function is PRODUCING RESULTS.";

console.table(["Audi", "Volvo", "Ford"]);


/*
Console table()
Example

Write an array as a table in the console:
console.table(["Audi", "Volvo", "Ford"]);

Write an object as a table in the console:

console.table({firstname:"John", lastname:"Doe"});
More examples below.

Description
The table() method writes a table to the console.

Note
You can sort the table by clicking the column names.

Syntax
console.table(tabledata, tablecolumns)
Parameters
Parameter	Description
tabledata	Required.
The data to fill the table with.
tablecolumns	Optional.
An array with the names of the table columns.
ADVERTISEMENT

More Examples
Using an array of objects:

const car1 = {name:"Audi", model:"A4"}
const car2 = {name:"Volvo", model:"XC90"}
const car3 = {name:"Ford", model:"Fusion"}

console.table([car1, car2, car3]);
Only include the "model" column in the table:

const car1 = {name:"Audi", model:"A4"}
const car2 = {name:"Volvo", model:"XC90"}
const car3 = {name:"Ford", model:"Fusion"}

console.table([car1, car2, car3], ["model"]);
Browser Support
console.table() is supported in all modern browsers:

Chrome	Edge	Firefox	Safari	Opera
Yes	Yes	Yes	Yes	Yes
console.table() is not supported in Internet Explorer 11 (or earlier).

*/



CREATE TABLE generic_name (

  Element_1 internal,
  Element_2 var(64) default NULL,
  Element_3 int default NULL,

);