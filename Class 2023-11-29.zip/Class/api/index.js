const express = require('express')

const app = express();

// Running this program, our computer becomes a server, and other computers can connect to ours by a "client" program.
// Check the folder "localhost://4000";

app.listen(4000, () => {
    console.log('aplicação rodando na porta 4000')
})

app.get('/', (request, response) => {
    response.send("Hello World")
})